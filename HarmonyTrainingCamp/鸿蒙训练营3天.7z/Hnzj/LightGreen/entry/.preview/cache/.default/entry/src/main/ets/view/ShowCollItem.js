import Constants from '@bundle:com.dixin.myapplication/entry/ets/common/Constants';
import { cancelColl, getColl, stringToArr } from '@bundle:com.dixin.myapplication/entry/ets/viewModel/MyUtils';
export default class ShowCollItem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.item = undefined;
        this.__collPoems = new SynchedPropertyObjectTwoWayPU(params.collPoems, this, "collPoems");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.item !== undefined) {
            this.item = params.item;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__collPoems.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__collPoems.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get collPoems() {
        return this.__collPoems.get();
    }
    set collPoems(newValue) {
        this.__collPoems.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 10 });
            Column.debugLine("view/ShowCollItem.ets(10:5)");
            Column.width('90%');
            Column.backgroundColor('#abc');
            Column.padding({
                top: 10,
                bottom: 10
            });
            Column.borderRadius(30);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.item.content);
            Text.debugLine("view/ShowCollItem.ets(11:7)");
            Text.fontSize(20);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/ShowCollItem.ets(13:7)");
            Row.padding({
                left: 20
            });
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.item.author);
            Text.debugLine("view/ShowCollItem.ets(14:9)");
            __Text__textStyle('30%');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`《${this.item.origin}》`);
            Text.debugLine("view/ShowCollItem.ets(16:9)");
            __Text__textStyle('50%');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(stringToArr(this.item.category, '-')[1]);
            Text.debugLine("view/ShowCollItem.ets(18:9)");
            Text.fontSize(16);
            __Text__textStyle('20%');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('删除');
            Button.debugLine("view/ShowCollItem.ets(27:7)");
            Button.width(100);
            Button.fontSize(16);
            Button.type(ButtonType.Normal);
            Button.borderRadius(10);
            Button.backgroundColor('#ffb8abab');
            Button.fontColor('#ffd01313');
            Button.onClick(() => {
                cancelColl(this.item.content);
                //更新页面，即更新 父组件的 collPoems 数组。那么该如何父子联动更新呢。当然是 state---link
                this.collPoems = getColl(Constants.baiShi);
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
function __Text__textStyle(widthVal) {
    Text.fontSize(20);
    Text.width(widthVal);
    Text.maxLines(1);
    Text.textOverflow({ overflow: TextOverflow.Ellipsis });
}
//# sourceMappingURL=ShowCollItem.js.map