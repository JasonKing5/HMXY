// 帝心推荐 布局内容
import Constants from '@bundle:com.dixin.myapplication/entry/ets/common/Constants';
import { PoemFromApi } from '@bundle:com.dixin.myapplication/entry/ets/data/LightGreenData';
import { cancelColl, saveCurrentPoem } from '@bundle:com.dixin.myapplication/entry/ets/viewModel/MyUtils';
export default class Recomment extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.pArr = Constants.dXinRecommend;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.pArr !== undefined) {
            this.pArr = params.pArr;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create({ space: 20 });
            List.debugLine("view/Recomment.ets(11:5)");
            List.alignListItem(ListItemAlign.Center);
            List.padding({
                top: 30
            });
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, index) => {
                const item = _item;
                {
                    const isLazyCreate = true;
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, isLazyCreate);
                        __ListItem__dxinListStyle();
                        ListItem.debugLine("view/Recomment.ets(13:9)");
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        ListItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        {
                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                if (isInitialRender) {
                                    ViewPU.create(new 
                                    // es6的对象简写形式
                                    ItemRow(this, { item, index }, undefined, elmtId));
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                        }
                        ListItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        {
                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                if (isInitialRender) {
                                    ViewPU.create(new 
                                    // es6的对象简写形式
                                    ItemRow(this, { item, index }, undefined, elmtId));
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                        }
                        ListItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, this.pArr, forEachItemGenFunction, undefined, true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        List.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
function __ListItem__dxinListStyle() {
    ListItem.width('90%');
    ListItem.height(40);
}
class ItemRow extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.item = undefined;
        this.index = undefined;
        this.__isColl = new ObservedPropertySimplePU(false, this, "isColl");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.item !== undefined) {
            this.item = params.item;
        }
        if (params.index !== undefined) {
            this.index = params.index;
        }
        if (params.isColl !== undefined) {
            this.isColl = params.isColl;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__isColl.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__isColl.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get isColl() {
        return this.__isColl.get();
    }
    set isColl(newValue) {
        this.__isColl.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/Recomment.ets(43:5)");
            __Row__rowStyle(this.isColl ? '#ffe58686' : '#eee');
            Row.onClick(() => {
                this.isColl = !this.isColl;
                //判断是否收藏
                if (this.isColl) {
                    saveCurrentPoem(new PoemFromApi(this.item, '你猜', '帝心推荐', '帝心-喜欢'));
                }
                else {
                    // 给我当前这句诗词。从数组中移除即可
                    cancelColl(this.item);
                }
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.item);
            Text.debugLine("view/Recomment.ets(44:7)");
            Text.fontSize(20);
            Text.fontColor(this.index % 2 === 0 ? '#ff12aca7' : '#ff910fc1');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
function __Row__rowStyle(itemColor) {
    Row.width('100%');
    Row.height('100%');
    Row.borderRadius(20);
    Row.justifyContent(FlexAlign.Center);
    Row.backgroundColor(itemColor);
}
//# sourceMappingURL=Recomment.js.map