export class PoemFromApi {
    constructor(content, origin, author, category) {
        this.content = content;
        this.origin = origin;
        this.author = author;
        this.category = category;
    }
}
//# sourceMappingURL=LightGreenData.js.map