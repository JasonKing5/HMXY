if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Title_Params {
    hasBack?: boolean;
}
import router from "@ohos:router";
export default class Title extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.hasBack = false;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Title_Params) {
        if (params.hasBack !== undefined) {
            this.hasBack = params.hasBack;
        }
    }
    updateStateVars(params: Title_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private hasBack: boolean;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/Title.ets(7:5)");
            __Row__titleStyle();
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.hasBack) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create({ "id": 16777224, "type": 20000, params: [], "bundleName": "com.dixin.myapplication", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/view/Title.ets(9:9)");
                        Image.width(30);
                        Image.fillColor('#ffec3939');
                        Image.onClick(() => {
                            router.back();
                        });
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777229, "type": 20000, params: [], "bundleName": "com.dixin.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/view/Title.ets(17:7)");
            Image.width('60');
            Image.copyOption(CopyOptions.InApp);
            Image.draggable(true);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777220, "type": 10003, params: [], "bundleName": "com.dixin.myapplication", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/view/Title.ets(22:7)");
            Text.fontSize(30);
            Text.fontColor('#ffa11bd4');
        }, Text);
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
function __Row__titleStyle(): void {
    Row.width('90%');
    Row.height(80);
    Row.justifyContent(FlexAlign.SpaceEvenly);
}
