if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ItemRow_Params {
    item?: string;
    index?: number;
    isColl?: boolean;
}
interface Recomment_Params {
    pArr?: Array<string>;
}
import Constants from "@bundle:com.dixin.myapplication/entry/ets/common/Constants";
import { PoemFromApi } from "@bundle:com.dixin.myapplication/entry/ets/data/LightGreenData";
import { cancelColl, saveCurrentPoem } from "@bundle:com.dixin.myapplication/entry/ets/viewModel/MyUtils";
export default class Recomment extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.pArr = Constants.dXinRecommend;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Recomment_Params) {
        if (params.pArr !== undefined) {
            this.pArr = params.pArr;
        }
    }
    updateStateVars(params: Recomment_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private pArr: Array<string>;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 20 });
            List.debugLine("entry/src/main/ets/view/Recomment.ets(11:5)");
            List.alignListItem(ListItemAlign.Center);
            List.padding({
                top: 30
            });
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        __ListItem__dxinListStyle();
                        ListItem.debugLine("entry/src/main/ets/view/Recomment.ets(13:9)");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                if (isInitialRender) {
                                    let componentCall = new 
                                    // es6的对象简写形式
                                    ItemRow(this, { item, index }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/view/Recomment.ets", line: 15 });
                                    ViewPU.create(componentCall);
                                    let paramsLambda = () => {
                                        return {
                                            item,
                                            index
                                        };
                                    };
                                    componentCall.paramsGenerator_ = paramsLambda;
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                                }
                            }, { name: "ItemRow" });
                        }
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.pArr, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        ForEach.pop();
        List.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
function __ListItem__dxinListStyle(): void {
    ListItem.width('90%');
    ListItem.height(40);
}
class ItemRow extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.item = '日拱一卒无有尽，功不唐捐终入海';
        this.index = 0;
        this.__isColl = new ObservedPropertySimplePU(false, this, "isColl");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ItemRow_Params) {
        if (params.item !== undefined) {
            this.item = params.item;
        }
        if (params.index !== undefined) {
            this.index = params.index;
        }
        if (params.isColl !== undefined) {
            this.isColl = params.isColl;
        }
    }
    updateStateVars(params: ItemRow_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__isColl.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__isColl.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private item: string;
    private index: number;
    // 控制 每一行 ListItem 的颜色
    // @State itemColor:string = '#ffde5353'
    private __isColl: ObservedPropertySimplePU<boolean>;
    get isColl() {
        return this.__isColl.get();
    }
    set isColl(newValue: boolean) {
        this.__isColl.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/Recomment.ets(43:5)");
            __Row__rowStyle(this.isColl ? '#ffe58686' : '#eee');
            Row.onClick(() => {
                this.isColl = !this.isColl;
                //判断是否收藏
                if (this.isColl) {
                    saveCurrentPoem(new PoemFromApi(this.item, '你猜', '帝心推荐', '帝心-喜欢'));
                }
                else {
                    // 给我当前这句诗词。从数组中移除即可
                    cancelColl(this.item);
                }
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.item);
            Text.debugLine("entry/src/main/ets/view/Recomment.ets(44:7)");
            Text.fontSize(20);
            Text.fontColor(this.index % 2 === 0 ? '#ff12aca7' : '#ff910fc1');
        }, Text);
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
function __Row__rowStyle(itemColor: string): void {
    Row.width('100%');
    Row.height('100%');
    Row.borderRadius(20);
    Row.justifyContent(FlexAlign.Center);
    Row.backgroundColor(itemColor);
}
