if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    countdown?: number;
    angleVal?: number;
}
import router from "@ohos:router";
import Constants from "@bundle:com.dixin.myapplication/entry/ets/common/Constants";
import Title from "@bundle:com.dixin.myapplication/entry/ets/view/Title";
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__countdown = new ObservedPropertySimplePU(Constants.countdown, this, "countdown");
        this.__angleVal = new ObservedPropertySimplePU(0, this, "angleVal");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.countdown !== undefined) {
            this.countdown = params.countdown;
        }
        if (params.angleVal !== undefined) {
            this.angleVal = params.angleVal;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__countdown.purgeDependencyOnElmtId(rmElmtId);
        this.__angleVal.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__countdown.aboutToBeDeleted();
        this.__angleVal.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __countdown: ObservedPropertySimplePU<number>;
    get countdown() {
        return this.__countdown.get();
    }
    set countdown(newValue: number) {
        this.__countdown.set(newValue);
    }
    private __angleVal: ObservedPropertySimplePU<number>;
    get angleVal() {
        return this.__angleVal.get();
    }
    set angleVal(newValue: number) {
        this.__angleVal.set(newValue);
    }
    aboutToAppear() {
        // 定时执行
        let timerId: number = setInterval(() => {
            this.countdown--;
            if (this.countdown === 0) {
                //停止定时器。  建议停止
                clearInterval(timerId);
                // 跳转页面
                router.pushUrl({
                    url: "pages/Main"
                });
            }
            // 动画效果。
            Context.animateTo({
                curve: Curve.Linear,
                duration: 1000,
                iterations: -1
            }, () => {
                this.angleVal = 360;
            });
        }, 1000);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 30 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(36:5)");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor({ "id": 16777226, "type": 10001, params: [], "bundleName": "com.dixin.myapplication", "moduleName": "entry" });
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(37:7)");
            Row.width('100%');
            Row.height(50);
            Row.backgroundColor('#eee');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/Index.ets(38:9)");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.countdown + '秒进入');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(39:9)");
            Text.fontSize(30);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/Index.ets(46:7)");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['loading.jpg'], "bundleName": "com.dixin.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/Index.ets(47:7)");
            Image.width('40%');
            Image.borderRadius(90);
            Image.opacity(.5);
            Image.rotate({
                angle: this.angleVal
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/Index.ets(54:7)");
        }, Blank);
        Blank.pop();
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new Title(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 56 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {};
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "Title" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/Index.ets(58:7)");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create({ "id": 16777222, "type": 10003, params: [], "bundleName": "com.dixin.myapplication", "moduleName": "entry" });
            Text.debugLine("entry/src/main/ets/pages/Index.ets(60:7)");
            Text.fontSize(20);
            Text.fontColor('#fff38406');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/Index.ets(63:7)");
        }, Blank);
        Blank.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.dixin.myapplication", moduleName: "entry", pagePath: "pages/Index", integratedHsp: "false" });
