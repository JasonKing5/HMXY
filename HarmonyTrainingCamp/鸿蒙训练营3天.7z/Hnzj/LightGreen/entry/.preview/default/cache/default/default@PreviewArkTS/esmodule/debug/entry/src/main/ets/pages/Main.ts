if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Main_Params {
    currentIndex?: number;
}
import BaiPoem from "@bundle:com.dixin.myapplication/entry/ets/view/BaiPoem";
import Recomment from "@bundle:com.dixin.myapplication/entry/ets/view/Recomment";
import Title from "@bundle:com.dixin.myapplication/entry/ets/view/Title";
class Main extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__currentIndex = new ObservedPropertySimplePU(0
        // 自定义build函数组件
        , this, "currentIndex");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Main_Params) {
        if (params.currentIndex !== undefined) {
            this.currentIndex = params.currentIndex;
        }
    }
    updateStateVars(params: Main_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentIndex.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentIndex.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __currentIndex: ObservedPropertySimplePU<number>;
    get currentIndex() {
        return this.__currentIndex.get();
    }
    set currentIndex(newValue: number) {
        this.__currentIndex.set(newValue);
    }
    // 自定义build函数组件
    myTab(imgSrc: Resource, tabBarName: string, index: number, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/Main.ets(12:5)");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(imgSrc);
            Image.debugLine("entry/src/main/ets/pages/Main.ets(13:7)");
            Image.width(30);
            Image.fillColor(this.currentIndex === index ? '#ff0e7cea' : '#ffde1bb0');
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(tabBarName);
            Text.debugLine("entry/src/main/ets/pages/Main.ets(16:7)");
            Text.fontColor(this.currentIndex === index ? '#ff0e7cea' : '#ffde1bb0');
        }, Text);
        Text.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/Main.ets(22:5)");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor({ "id": 16777226, "type": 10001, params: [], "bundleName": "com.dixin.myapplication", "moduleName": "entry" });
            Column.justifyContent(FlexAlign.Start);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new Title(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Main.ets", line: 23 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {};
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "Title" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/Main.ets(24:7)");
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Tabs.create({ barPosition: BarPosition.Start });
            Tabs.debugLine("entry/src/main/ets/pages/Main.ets(25:7)");
            Tabs.vertical(false);
            Tabs.layoutWeight(1);
            Tabs.margin({
                bottom: 30
            });
            Tabs.onChange((index: number) => {
                this.currentIndex = index;
            });
        }, Tabs);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new BaiPoem(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Main.ets", line: 28 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {};
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                    }, { name: "BaiPoem" });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.myTab.call(this, { "id": 16777229, "type": 20000, params: [], "bundleName": "com.dixin.myapplication", "moduleName": "entry" }, '百诗斩', 0);
                } });
            TabContent.debugLine("entry/src/main/ets/pages/Main.ets(27:9)");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new Recomment(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Main.ets", line: 34 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {};
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                    }, { name: "Recomment" });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.myTab.call(this, { "id": 16777218, "type": 20000, params: [], "bundleName": "com.dixin.myapplication", "moduleName": "entry" }, '帝心推荐', 1);
                } });
            TabContent.debugLine("entry/src/main/ets/pages/Main.ets(33:9)");
        }, TabContent);
        TabContent.pop();
        Tabs.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Main";
    }
}
registerNamedRoute(() => new Main(undefined, {}), "", { bundleName: "com.dixin.myapplication", moduleName: "entry", pagePath: "pages/Main", integratedHsp: "false" });
