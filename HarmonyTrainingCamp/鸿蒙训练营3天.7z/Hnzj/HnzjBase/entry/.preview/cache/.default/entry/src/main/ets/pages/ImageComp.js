import router from '@ohos:router';
import TopTitle from '@bundle:com.dixin.hnzj/entry/ets/view/base/TopTitle';
class ImageComp extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        var _a;
        super(parent, __localStorage, elmtId);
        this.message = ((_a = router.getParams()) === null || _a === void 0 ? void 0 : _a['title']) || '图片';
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/ImageComp.ets(10:5)");
            Row.height('100%');
            Row.backgroundColor({ "id": 16777222, "type": 10001, params: [], "bundleName": "com.dixin.hnzj", "moduleName": "entry" });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 30 });
            Column.debugLine("pages/ImageComp.ets(11:7)");
            Column.width('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new TopTitle(this, { message: this.message }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Divider.create();
            Divider.debugLine("pages/ImageComp.ets(13:9)");
            if (!isInitialRender) {
                Divider.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 图片组件：字符串和资源类型
            // 字符串的src可以写相对目录和在线图片
            Image.create('https://ts1.cn.mm.bing.net/th/id/R-C.d46ed198d9727612c0662519b50410d8?rik=sqWV3BdJihecww&riu=http%3a%2f%2fpuui.qpic.cn%2fvpic_cover%2fw30347bf9az%2fw30347bf9az_hz.jpg%2f1280&ehk=aaD4gonEgVsaVzLjcBxHmIIMk4harCUo2vdgRN70zpY%3d&risl=&pid=ImgRaw&r=0');
            Image.debugLine("pages/ImageComp.ets(16:9)");
            // 图片组件：字符串和资源类型
            // 字符串的src可以写相对目录和在线图片
            Image.width(300);
            if (!isInitialRender) {
                // 图片组件：字符串和资源类型
                // 字符串的src可以写相对目录和在线图片
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //   本地资源 精灵图 icon
            Image.create({ "id": 16777218, "type": 20000, params: [], "bundleName": "com.dixin.hnzj", "moduleName": "entry" });
            Image.debugLine("pages/ImageComp.ets(20:9)");
            //   本地资源 精灵图 icon
            Image.width('50%');
            //   本地资源 精灵图 icon
            Image.fillColor(Color.Green);
            if (!isInitialRender) {
                //   本地资源 精灵图 icon
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 商品图片
            Image.create({ "id": 0, "type": 30000, params: ['pc.jpg'], "bundleName": "com.dixin.hnzj", "moduleName": "entry" });
            Image.debugLine("pages/ImageComp.ets(24:9)");
            // 商品图片
            Image.width(300);
            if (!isInitialRender) {
                // 商品图片
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new ImageComp(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=ImageComp.js.map