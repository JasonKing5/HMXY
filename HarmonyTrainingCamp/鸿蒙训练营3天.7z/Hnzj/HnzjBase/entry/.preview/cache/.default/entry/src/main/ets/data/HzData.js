// 本项目需要很多类型数据 都靠这个文件同意管理和产生数据
export class Poem {
    constructor(index, content, origin) {
        this.index = index;
        this.content = content;
        this.origin = origin;
    }
}
export class BtnNavigation {
    constructor(title, url) {
        this.title = title;
        this.url = url;
    }
}
//# sourceMappingURL=HzData.js.map