import router from '@ohos:router';
import TopTitle from '@bundle:com.dixin.hnzj/entry/ets/view/base/TopTitle';
class TextComp extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        var _a;
        super(parent, __localStorage, elmtId);
        this.message = ((_a = router.getParams()) === null || _a === void 0 ? void 0 : _a['title']) || '文本组件学习';
        this.age = 22;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
        if (params.age !== undefined) {
            this.age = params.age;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 30 });
            Column.debugLine("pages/TextComp.ets(11:5)");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor({ "id": 16777222, "type": 10001, params: [], "bundleName": "com.dixin.hnzj", "moduleName": "entry" });
            Column.justifyContent(FlexAlign.Center);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new TopTitle(this, { message: this.message }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Divider.create();
            Divider.debugLine("pages/TextComp.ets(13:7)");
            if (!isInitialRender) {
                Divider.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 文本组件只能写两种内容。字符串和资源类型
            Text.create('字符串资源1：${this.age}单引号');
            Text.debugLine("pages/TextComp.ets(15:7)");
            if (!isInitialRender) {
                // 文本组件只能写两种内容。字符串和资源类型
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 文本组件只能写两种内容。字符串和资源类型
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("字符串资源2：双引号");
            Text.debugLine("pages/TextComp.ets(16:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`字符串资源3：${this.age}反引号`);
            Text.debugLine("pages/TextComp.ets(17:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 资源类型
            Text.create({ "id": 16777226, "type": 10003, params: [], "bundleName": "com.dixin.hnzj", "moduleName": "entry" });
            Text.debugLine("pages/TextComp.ets(20:7)");
            if (!isInitialRender) {
                // 资源类型
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 资源类型
        Text.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new TextComp(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=TextComp.js.map