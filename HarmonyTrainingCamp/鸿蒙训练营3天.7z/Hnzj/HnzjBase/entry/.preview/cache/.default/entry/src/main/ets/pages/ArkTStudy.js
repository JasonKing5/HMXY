// 基本语法快速学习
import { Poem } from '@bundle:com.dixin.hnzj/entry/ets/data/HzData';
import TopTitle from '@bundle:com.dixin.hnzj/entry/ets/view/base/TopTitle';
class Person {
    constructor(name, sex) {
        this.name = name;
        this.sex = sex;
    }
}
class ArkTStudy extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.message = '日拱一卒无有尽，功不唐捐终入海';
        this.age = 32;
        this.flag = true;
        this.dxin = new Person('帝心', 18);
        this.poemArr = [];
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
        if (params.age !== undefined) {
            this.age = params.age;
        }
        if (params.flag !== undefined) {
            this.flag = params.flag;
        }
        if (params.dxin !== undefined) {
            this.dxin = params.dxin;
        }
        if (params.poemArr !== undefined) {
            this.poemArr = params.poemArr;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 生命周期函数
    aboutToAppear() {
        //业务代码  加载资源 http
        this.poemArr = [
            new Poem(0, '去二仙桥要走成华达大道', '谭警官'),
            new Poem(1, '长城炮', '炮姐'),
            new Poem(2, '何须浅碧深红色，自是花中第一流', '帝心')
        ];
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 30 });
            Column.debugLine("pages/ArkTStudy.ets(36:5)");
            __Column__clmStyle();
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new TopTitle(this, { message: this.message }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Divider.create();
            Divider.debugLine("pages/ArkTStudy.ets(38:7)");
            if (!isInitialRender) {
                Divider.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, index) => {
                const item = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create(`${item.index}<->${item.content}<->${item.origin}`);
                    Text.debugLine("pages/ArkTStudy.ets(40:9)");
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
            };
            this.forEachUpdateFunction(elmtId, this.poemArr, forEachItemGenFunction, undefined, true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
function __Column__clmStyle() {
    Column.width('100%');
    Column.height('100%');
    Column.backgroundColor({ "id": 16777222, "type": 10001, params: [], "bundleName": "com.dixin.hnzj", "moduleName": "entry" });
    Column.justifyContent(FlexAlign.Center);
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new ArkTStudy(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=ArkTStudy.js.map