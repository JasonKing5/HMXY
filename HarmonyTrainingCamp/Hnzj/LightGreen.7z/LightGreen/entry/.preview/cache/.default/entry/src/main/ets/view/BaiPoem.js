import router from '@ohos:router';
import { PoemFromApi } from '@bundle:com.dixin.myapplication/entry/ets/data/LightGreenData';
import { cancelColl, getPoemDate, saveCurrentPoem } from '@bundle:com.dixin.myapplication/entry/ets/viewModel/MyUtils';
export default class BaiPoem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__baiPoemObj = new ObservedPropertyObjectPU(new PoemFromApi('何须浅碧深红色，自是花中第一流', `无题`, `帝心`, `帝心-桂花`), this, "baiPoemObj");
        this.__isCollection = new ObservedPropertySimplePU(false, this, "isCollection");
        this.__angleVal = new ObservedPropertySimplePU(0, this, "angleVal");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.baiPoemObj !== undefined) {
            this.baiPoemObj = params.baiPoemObj;
        }
        if (params.isCollection !== undefined) {
            this.isCollection = params.isCollection;
        }
        if (params.angleVal !== undefined) {
            this.angleVal = params.angleVal;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__baiPoemObj.purgeDependencyOnElmtId(rmElmtId);
        this.__isCollection.purgeDependencyOnElmtId(rmElmtId);
        this.__angleVal.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__baiPoemObj.aboutToBeDeleted();
        this.__isCollection.aboutToBeDeleted();
        this.__angleVal.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get baiPoemObj() {
        return this.__baiPoemObj.get();
    }
    set baiPoemObj(newValue) {
        this.__baiPoemObj.set(newValue);
    }
    get isCollection() {
        return this.__isCollection.get();
    }
    set isCollection(newValue) {
        this.__isCollection.set(newValue);
    }
    get angleVal() {
        return this.__angleVal.get();
    }
    set angleVal(newValue) {
        this.__angleVal.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 20 });
            Column.debugLine("view/BaiPoem.ets(14:5)");
            Column.onClick(async () => {
                this.baiPoemObj = await getPoemDate();
                //还应该更新按钮的收藏状态
                this.isCollection = false;
                // 旋转一下特效
                Context.animateTo({ duration: 500 }, () => {
                    this.angleVal = this.angleVal === 0 ? 360 : 0;
                });
            });
            Column.height('90%');
            Column.justifyContent(FlexAlign.SpaceEvenly);
            Column.rotate({
                // x:1,
                // y:1,
                z: 1,
                angle: this.angleVal
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.baiPoemObj.content);
            Text.debugLine("view/BaiPoem.ets(15:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.baiPoemObj.origin);
            Text.debugLine("view/BaiPoem.ets(16:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.baiPoemObj.author);
            Text.debugLine("view/BaiPoem.ets(17:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.baiPoemObj.category);
            Text.debugLine("view/BaiPoem.ets(18:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/BaiPoem.ets(19:7)");
            Row.width('90%');
            Row.height(40);
            Row.justifyContent(FlexAlign.SpaceEvenly);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel(this.isCollection ? '已收藏' : '收藏');
            Button.debugLine("view/BaiPoem.ets(20:9)");
            Button.onClick(() => {
                this.isCollection = !this.isCollection;
                // todo 不能直接去保存数据。应该根据状态变量。
                if (this.isCollection) {
                    saveCurrentPoem(this.baiPoemObj); //收藏的业务逻辑 ： 保存当前数据 baiPoemObj
                }
                else {
                    // todo 删除曾经收藏过的这首诗词
                    cancelColl(this.baiPoemObj.content);
                }
            });
            Button.width('30%');
            Button.backgroundColor(this.isCollection ? '#ffc19c9c' : '#ff56a56b');
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('去查看收藏');
            Button.debugLine("view/BaiPoem.ets(34:9)");
            Button.backgroundColor('#ff56a56b');
            Button.onClick(() => {
                // 跳转页面
                router.pushUrl({
                    url: "pages/ShowColl"
                });
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=BaiPoem.js.map