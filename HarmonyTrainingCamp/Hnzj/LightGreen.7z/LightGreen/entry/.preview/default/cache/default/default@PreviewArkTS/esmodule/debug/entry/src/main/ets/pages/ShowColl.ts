if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ShowColl_Params {
    collPoems?: PoemFromApi[];
}
import Constants from "@bundle:com.dixin.myapplication/entry/ets/common/Constants";
import type { PoemFromApi } from '../data/LightGreenData';
import ShowCollItem from "@bundle:com.dixin.myapplication/entry/ets/view/ShowCollItem";
import Title from "@bundle:com.dixin.myapplication/entry/ets/view/Title";
import { getColl } from "@bundle:com.dixin.myapplication/entry/ets/viewModel/MyUtils";
class ShowColl extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__collPoems = new ObservedPropertyObjectPU(getColl(Constants.baiShi) as PoemFromApi[], this, "collPoems");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ShowColl_Params) {
        if (params.collPoems !== undefined) {
            this.collPoems = params.collPoems;
        }
    }
    updateStateVars(params: ShowColl_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__collPoems.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__collPoems.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 我想要的是收藏起来的数组，好多对象。
    private __collPoems: ObservedPropertyObjectPU<PoemFromApi[]>;
    get collPoems() {
        return this.__collPoems.get();
    }
    set collPoems(newValue: PoemFromApi[]) {
        this.__collPoems.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 30 });
            Column.debugLine("entry/src/main/ets/pages/ShowColl.ets(15:5)");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor({ "id": 16777226, "type": 10001, params: [], "bundleName": "com.dixin.myapplication", "moduleName": "entry" });
            Column.justifyContent(FlexAlign.Start);
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new Title(this, { hasBack: true }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/ShowColl.ets", line: 16 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            hasBack: true
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "Title" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/ShowColl.ets(17:7)");
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.collPoems.length === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('请快去收藏你喜欢的诗句吧');
                        Text.debugLine("entry/src/main/ets/pages/ShowColl.ets(19:9)");
                        Text.fontSize(40);
                        Text.fontColor('#ffde3e3e');
                        Text.width(40);
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 20 });
            List.debugLine("entry/src/main/ets/pages/ShowColl.ets(24:7)");
            List.alignListItem(ListItemAlign.Center);
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.debugLine("entry/src/main/ets/pages/ShowColl.ets(26:11)");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                if (isInitialRender) {
                                    let componentCall = new ShowCollItem(this, { item, collPoems: this.__collPoems }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/ShowColl.ets", line: 27 });
                                    ViewPU.create(componentCall);
                                    let paramsLambda = () => {
                                        return {
                                            item,
                                            collPoems: this.collPoems
                                        };
                                    };
                                    componentCall.paramsGenerator_ = paramsLambda;
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                                }
                            }, { name: "ShowCollItem" });
                        }
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.collPoems, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        ForEach.pop();
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ShowColl";
    }
}
registerNamedRoute(() => new ShowColl(undefined, {}), "", { bundleName: "com.dixin.myapplication", moduleName: "entry", pagePath: "pages/ShowColl", integratedHsp: "false" });
