if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ShowCollItem_Params {
    item?: PoemFromApi;
    collPoems?: PoemFromApi[];
}
import Constants from "@bundle:com.dixin.myapplication/entry/ets/common/Constants";
import { PoemFromApi } from "@bundle:com.dixin.myapplication/entry/ets/data/LightGreenData";
import { cancelColl, getColl, stringToArr } from "@bundle:com.dixin.myapplication/entry/ets/viewModel/MyUtils";
export default class ShowCollItem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.item = new PoemFromApi('temp', 'temp', 'temp', 'temp-temp');
        this.__collPoems = new SynchedPropertyObjectTwoWayPU(params.collPoems, this, "collPoems");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ShowCollItem_Params) {
        if (params.item !== undefined) {
            this.item = params.item;
        }
    }
    updateStateVars(params: ShowCollItem_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__collPoems.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__collPoems.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private item: PoemFromApi;
    private __collPoems: SynchedPropertySimpleOneWayPU<PoemFromApi[]>;
    get collPoems() {
        return this.__collPoems.get();
    }
    set collPoems(newValue: PoemFromApi[]) {
        this.__collPoems.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/view/ShowCollItem.ets(10:5)");
            Column.width('90%');
            Column.backgroundColor('#abc');
            Column.padding({
                top: 10,
                bottom: 10
            });
            Column.borderRadius(30);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.item.content);
            Text.debugLine("entry/src/main/ets/view/ShowCollItem.ets(11:7)");
            Text.fontSize(20);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/ShowCollItem.ets(13:7)");
            Row.padding({
                left: 20
            });
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.item.author);
            Text.debugLine("entry/src/main/ets/view/ShowCollItem.ets(14:9)");
            __Text__textStyle('30%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`《${this.item.origin}》`);
            Text.debugLine("entry/src/main/ets/view/ShowCollItem.ets(16:9)");
            __Text__textStyle('50%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(stringToArr(this.item.category, '-')[1]);
            Text.debugLine("entry/src/main/ets/view/ShowCollItem.ets(18:9)");
            Text.fontSize(16);
            __Text__textStyle('20%');
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('删除');
            Button.debugLine("entry/src/main/ets/view/ShowCollItem.ets(27:7)");
            Button.width(100);
            Button.fontSize(16);
            Button.type(ButtonType.Normal);
            Button.borderRadius(10);
            Button.backgroundColor('#ffb8abab');
            Button.fontColor('#ffd01313');
            Button.onClick(() => {
                cancelColl(this.item.content);
                //更新页面，即更新 父组件的 collPoems 数组。那么该如何父子联动更新呢。当然是 state---link
                this.collPoems = getColl(Constants.baiShi) as PoemFromApi[];
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
function __Text__textStyle(widthVal: string): void {
    Text.fontSize(20);
    Text.width(widthVal);
    Text.maxLines(1);
    Text.textOverflow({ overflow: TextOverflow.Ellipsis });
}
