if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface BaiPoem_Params {
    baiPoemObj?: PoemFromApi;
    isCollection?: boolean;
    angleVal?: number;
}
import router from "@ohos:router";
import { PoemFromApi } from "@bundle:com.dixin.myapplication/entry/ets/data/LightGreenData";
import { cancelColl, getPoemDate, saveCurrentPoem } from "@bundle:com.dixin.myapplication/entry/ets/viewModel/MyUtils";
export default class BaiPoem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__baiPoemObj = new ObservedPropertyObjectPU(new PoemFromApi('何须浅碧深红色，自是花中第一流', `无题`, `帝心`, `帝心-桂花`), this, "baiPoemObj");
        this.__isCollection = new ObservedPropertySimplePU(false, this, "isCollection");
        this.__angleVal = new ObservedPropertySimplePU(0, this, "angleVal");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: BaiPoem_Params) {
        if (params.baiPoemObj !== undefined) {
            this.baiPoemObj = params.baiPoemObj;
        }
        if (params.isCollection !== undefined) {
            this.isCollection = params.isCollection;
        }
        if (params.angleVal !== undefined) {
            this.angleVal = params.angleVal;
        }
    }
    updateStateVars(params: BaiPoem_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__baiPoemObj.purgeDependencyOnElmtId(rmElmtId);
        this.__isCollection.purgeDependencyOnElmtId(rmElmtId);
        this.__angleVal.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__baiPoemObj.aboutToBeDeleted();
        this.__isCollection.aboutToBeDeleted();
        this.__angleVal.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __baiPoemObj: ObservedPropertyObjectPU<PoemFromApi>;
    get baiPoemObj() {
        return this.__baiPoemObj.get();
    }
    set baiPoemObj(newValue: PoemFromApi) {
        this.__baiPoemObj.set(newValue);
    }
    private __isCollection: ObservedPropertySimplePU<boolean>;
    get isCollection() {
        return this.__isCollection.get();
    }
    set isCollection(newValue: boolean) {
        this.__isCollection.set(newValue);
    }
    private __angleVal: ObservedPropertySimplePU<number>;
    get angleVal() {
        return this.__angleVal.get();
    }
    set angleVal(newValue: number) {
        this.__angleVal.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/view/BaiPoem.ets(14:5)");
            Column.onClick(async () => {
                this.baiPoemObj = await getPoemDate();
                //还应该更新按钮的收藏状态
                this.isCollection = false;
                // 旋转一下特效
                Context.animateTo({ duration: 500 }, () => {
                    this.angleVal = this.angleVal === 0 ? 360 : 0;
                });
            });
            Column.height('90%');
            Column.justifyContent(FlexAlign.SpaceEvenly);
            Column.rotate({
                // x:1,
                // y:1,
                z: 1,
                angle: this.angleVal
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.baiPoemObj.content);
            Text.debugLine("entry/src/main/ets/view/BaiPoem.ets(15:7)");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.baiPoemObj.origin);
            Text.debugLine("entry/src/main/ets/view/BaiPoem.ets(16:7)");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.baiPoemObj.author);
            Text.debugLine("entry/src/main/ets/view/BaiPoem.ets(17:7)");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.baiPoemObj.category);
            Text.debugLine("entry/src/main/ets/view/BaiPoem.ets(18:7)");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/BaiPoem.ets(19:7)");
            Row.width('90%');
            Row.height(40);
            Row.justifyContent(FlexAlign.SpaceEvenly);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(this.isCollection ? '已收藏' : '收藏');
            Button.debugLine("entry/src/main/ets/view/BaiPoem.ets(20:9)");
            Button.onClick(() => {
                this.isCollection = !this.isCollection;
                // todo 不能直接去保存数据。应该根据状态变量。
                if (this.isCollection) {
                    saveCurrentPoem(this.baiPoemObj); //收藏的业务逻辑 ： 保存当前数据 baiPoemObj
                }
                else {
                    // todo 删除曾经收藏过的这首诗词
                    cancelColl(this.baiPoemObj.content);
                }
            });
            Button.width('30%');
            Button.backgroundColor(this.isCollection ? '#ffc19c9c' : '#ff56a56b');
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('去查看收藏');
            Button.debugLine("entry/src/main/ets/view/BaiPoem.ets(34:9)");
            Button.backgroundColor('#ff56a56b');
            Button.onClick(() => {
                // 跳转页面
                router.pushUrl({
                    url: "pages/ShowColl"
                });
            });
        }, Button);
        Button.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
